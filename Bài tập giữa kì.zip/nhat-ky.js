/* FitPlan Studio — Nhật ký: chỉ giữ phần JS màn này cần (từ common.js + workspace-core.js + member.js) */
const $=s=>document.querySelector(s),dt=n=>{const d=new Date();d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* lưu trữ (khoá riêng để không đè dữ liệu của bản nhiều trang) */
const ls={get(k,f){try{const v=localStorage.getItem(k);return v?JSON.parse(v):f}catch(e){return f}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const KEY='fp_state_nhatky';

/* hằng số — ROOT='../' để các liên kết trên thanh điều hướng khớp cấu trúc thư mục gốc (đặt file trong member/) */
const ROOT='../';
const RL={member:'Người tập'};
const NAV={member:[['dash','Dashboard','member/dashboard.html'],['plan','Kế hoạch','member/plan.html'],['log','Nhật ký','member/log.html']]};

/* dữ liệu demo */
let D={
log:[{id:1,d:dt(0),ex:'Squat 3x12',ok:'Xong'},{id:2,d:dt(1),ex:'Plank 3x30s',ok:'Xong'},{id:3,d:dt(2),ex:'Chạy 20 phút',ok:'Xong'},{id:4,d:dt(5),ex:'Chạy 20 phút',ok:'Bỏ dở'}],
notif:{member:[{id:1,read:false},{id:2,read:false},{id:3,read:true}]}};
let nid=100;
const sv=ls.get(KEY);if(sv&&sv.D&&sv.D.log){D=sv.D;nid=sv.nid}
const save=()=>ls.set(KEY,{D,nid});

/* phiên: người tập đã đăng nhập sẵn (bản gốc đọc từ localStorage) */
const U={name:'Nguyễn Văn An',role:'member'};
const unread=()=>D.notif.member.filter(n=>!n.read).length;

/* trạng thái giao diện */
let PAGE='log',S='log',WS=true,ed={},er={},tk=0;
const VIEW={},F={},A={},FS={},DEF={};

/* helper dựng HTML */
const h=(t,s)=>`<div class=top><h1>${t}</h1><p>${s}</p></div>`,bd=(c,t)=>`<span class="b ${c}">${t}</span>`,bx=(m,x='')=>`<div class=sb>${m}${x}</div>`;
const bt=(t,a,i='',c='',k='')=>`<button type=button class="btn ${c}" data-a="${a}" data-i="${i}" data-k="${k}">${t}</button>`;
const fld=(f,v,e)=>`<label>${f.l}${f.t=='select'?`<select name=${f.n}>${f.o.map(o=>`<option value="${esc(o)}" ${o==v?'selected':''}>${esc(o)||'— Chọn —'}</option>`).join('')}</select>`:f.t=='area'?`<textarea name=${f.n} rows=3>${esc(v)}</textarea>`:`<input name=${f.n} type=${f.t||'text'} value="${esc(v)}">`}${e?`<span class=err>${e}</span>`:''}</label>`;
const chk=(fs,d)=>{const e={};fs.forEach(x=>{const v=(d[x.n]||'').toString().trim();if(x.req&&!v)e[x.n]=x.l+' không được để trống.';else if(x.min&&!(+v>=x.min))e[x.n]=x.l+' phải là số dương.'});return e};

/* layout chung */
const head=()=>{const n=unread();
return `<header><a class=logo href="${ROOT}index.html">FitPlan Studio</a><nav>`
+NAV.member.map(x=>`<a class="tab ${x[0]==PAGE?'on':''}" href="${ROOT+x[2]}">${x[1]}</a>`).join('')
+`<a class="tab" href="${ROOT}notifications.html">Thông báo${n?` <span class=dot>${n}</span>`:''}</a>`
+`<a class="tab" href="${ROOT}profile.html" title="${RL[U.role]}">${esc(U.name)}</a>`
+`<a class="tab" href="${ROOT}settings.html">Cài đặt</a>`
+bt('Đăng xuất','out','','gh')
+`</nav></header>`};
const foot=()=>`<footer>FitPlan Studio — BTL-29 · <a href="${ROOT}index.html">Trang chủ</a></footer>`;

function draw(l){const t=++tk;
$('#app').innerHTML=head()+'<main id=v></main>'+foot();
const m=$('#v'),fill=()=>{if(t!=tk)return;m.innerHTML=VIEW[S]()};
l&&WS?(m.innerHTML=bx('Đang tải...'),setTimeout(fill,300)):fill();save()}

let tm;const toast=m=>{const e=$('#tt');e.textContent=m;e.className='tt on';clearTimeout(tm);tm=setTimeout(()=>e.className='tt',1800)};

/* bảng quản lý + form thêm/sửa (workspace-core.js) */
function mgr(k,t,fs,cols,o={}){FS[k]=fs;const e=ed[k]!=null?D[k].find(x=>x.id==ed[k]):null,r=D[k];
return `<form class=card data-f=${k}><h3>${e?'Sửa':'Thêm'} ${t}</h3>${fs.map(f=>fld(f,e?e[f.n]:f.d,er[k]&&er[k][f.n])).join('')}<button class="btn pr">${e?'Lưu':'Thêm'}</button> ${e?bt('Huỷ','cancel','','gh',k):''}</form>`+(r.length?`<div class=wrap><table><tr>${cols.map(c=>`<th>${c[0]}`).join('')}<th></tr>${r.map(x=>`<tr>${cols.map(c=>`<td>${c[1](x)}`).join('')}<td>${bt('Sửa','edit',x.id,'',k)} ${bt('Xoá','del',x.id,'er',k)}</tr>`).join('')}</table></div>`:bx(o.empty))}
const gen=(d,k)=>{const fs=FS[k],e=chk(fs,d);er[k]=e;if(Object.keys(e).length)return draw();fs.forEach(x=>{if(x.t=='number')d[x.n]=+d[x.n]});if(ed[k]!=null)Object.assign(D[k].find(x=>x.id==ed[k]),d);else D[k].push({id:++nid,...(DEF[k]||{}),...d});ed[k]=null;toast('Đã lưu');draw()};

/* màn Nhật ký (member.js) */
VIEW.log=()=>h('Nhật ký tập','Ghi nhận buổi tập đã thực hiện')+mgr('log','buổi tập',[{n:'d',l:'Ngày',t:'date',req:1,d:dt(0)},{n:'ex',l:'Bài tập',req:1},{n:'ok',l:'Kết quả',t:'select',o:['Xong','Bỏ dở']}],[['Ngày',x=>x.d],['Bài tập',x=>x.ex],['Kết quả',x=>bd(x.ok=='Xong'?'ok':'wa',x.ok)]],{empty:'Chưa có buổi tập nào.'});

Object.assign(A,{
edit:(i,k)=>{ed[k]=i;er[k]={};draw()},
cancel:(i,k)=>{ed[k]=null;er[k]={};draw()},
del:(i,k)=>{D[k]=D[k].filter(x=>x.id!=i);if(ed[k]==i)ed[k]=null;draw()},
out:()=>{location.href=ROOT+'index.html'}});
F._g=gen;

/* sự kiện */
document.addEventListener('submit',e=>{e.preventDefault();const f=e.target,k=f.dataset.f,fn=F[k]||F._g;if(fn)fn(Object.fromEntries(new FormData(f)),k)});
document.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(b&&A[b.dataset.a])A[b.dataset.a](b.dataset.i,b.dataset.k)});

/* khởi động */
draw(true);
